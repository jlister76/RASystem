'use strict';

module.exports = function(Qtlystatus) {

};
