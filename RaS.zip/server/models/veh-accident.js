'use strict';

module.exports = function(VehAccident) {

};
