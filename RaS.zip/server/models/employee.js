'use strict';

module.exports = function(Employee) {

};
