'use strict';

module.exports = function(Injury) {

};
