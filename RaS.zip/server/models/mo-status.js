'use strict';

module.exports = function(Mostatus) {

};
